package org.lms;

/* Color codes to use in the CLI */

public class AnsiColorCodes
{
    public static final String DEFAULT_COLOR = "\033[0m";
    public static final String RED_COLOR = "\033[31m";
    public static final String GREEN_COLOR = "\033[32m";
    public static final String BLUE_COLOR = "\033[34m";
}
