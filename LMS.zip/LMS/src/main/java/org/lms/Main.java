package org.lms;

/* Class where everything will be run */
public class Main
{
    public static void main(String[] args)
    {
        // Instantiate the OptionsMenu
        OptionsMenu optionsMenu = new OptionsMenu();

        // Run the menu
        optionsMenu.displayMenu();
    }
}
